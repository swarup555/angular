import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { first, filter } from 'rxjs/operators';
import { SignupService} from '../../_services/signup.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  signupform: FormGroup;
  get f() { return this.signupform.controls; }
  constructor(  private router: Router ,private formBuilder: FormBuilder,private signupservice: SignupService) { }

  ngOnInit(): void {
    this.signupform = this.formBuilder.group({
      name: [''],
      mobile: [''],
      email: [''],
    });
  }
  onSubmit() {
    this.signupservice.register(this.signupform.value)
    .pipe(first())
    .subscribe(
      data => {
          console.log(data);
          this.router.navigate(['/otp']);
      },
      error => {
        this.router.navigate(['/otp']);
        alert("error");
      });
  }
}
